import { Component, EventEmitter, Input, Output } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';

import {ToastrService} from 'ngx-toastr';
import { EmployeeService } from 'src/app/shared/services/employees.service';
@Component({
  selector: 'app-add-edit-employee',
  templateUrl: './add-edit-employee.component.html',
  styleUrls: ['./add-edit-employee.component.scss']
})
export class AddEditEmployeeComponent {

 @Input() employee: any;
 @Output() close = new EventEmitter();

  public employeeForm = new FormGroup({
    firstName: new FormControl("", [Validators.required,Validators.minLength(3),Validators.maxLength(100)]),
    lastName: new FormControl("",[Validators.required,Validators.minLength(3),Validators.maxLength(100)]),
    email: new FormControl("",[Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
    contactNumber: new FormControl("",[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]),
    department: new FormControl("",[Validators.required]),
    gender: new FormControl("",[Validators.required]),
    date: new FormControl("",[Validators.required]),
    password: new FormControl("",[Validators.required,Validators.pattern("")]),
    confirmpassword: new FormControl("",[Validators.required,Validators.pattern("")]),
    acceptTerms: new FormControl("",[Validators.required])
  });

  constructor(private employeeService: EmployeeService,
    private toastrService: ToastrService){}

    ngOnInit(){
      if(this.employee){
        this.employeeForm.patchValue(this.employee);
        console.log(this.employee);       
      }
    }

    public onClose() : void {
      this.close.emit();
    }

  public save(): void{
    let payload = this.assignValueToModel();
    if(!this.employee){
      this.addEmployee(payload);
    }
    else{
      this.updateEmployee(payload);
    }
  }

  private addEmployee(payload : any) :void{
    this.employeeService.addEmployee(payload).subscribe((response :any) => {
      this.toastrService.success("Employee added successfully","success");
      this.onClose();
    },(error:any) => {
      this.toastrService.error("error adding ","Error");
    });
  }

  private updateEmployee(payload : any) :void{
    this.employeeService.updateEmployee(payload).subscribe((response :any) => {
      this.toastrService.success("Employee updated successfully","success");
      this.onClose();
    },(error:any) => {
      this.toastrService.error("error updating","Error");
    });
  }

  private assignValueToModel(): any{
    let employee = {
      "id": this.employee ? this.employee.id : 0,
      "firstName": this.employeeForm.get("firstName")?.value,
      "lastName": this.employeeForm.get("lastName")?.value,
      "email": this.employeeForm.get("email")?.value,
      "contactNumber": this.employeeForm.get("contactNumber")?.value,
      "department": this.employeeForm.get("department")?.value,
      "gender": this.employeeForm.get("gender")?.value,
      "date": this.employeeForm.get("date")?.value,
      "password": this.employeeForm.get("password")?.value,
      "confirmpassword": this.employeeForm.get("confirmpassword")?.value,
      "acceptTerms": this.employeeForm.get("acceptTerms")?.value
    };
    return employee;
  }

  public checkIfControlValid(controlName: string): any {
    return this.employeeForm.get(controlName)?.invalid && 
      this.employeeForm.get(controlName)?.errors && 
      (this.employeeForm.get(controlName)?.dirty || this.employeeForm.get(controlName)?.touched);
  }

  public checkControlHasError(controlName: string, error: string): any {
    return this.employeeForm.get(controlName)?.hasError(error);
  }

}

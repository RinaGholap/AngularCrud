import { Component } from '@angular/core';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.scss']
})
export class BannerComponent {
  public CompanyName : string = "Aress";
  public Details : string = "You can rely on us as your Professional, Reliable and Long Term Technology Partner!";
  public show(){
   
    this.Details =  "Hope you enjoy";
  }
}
